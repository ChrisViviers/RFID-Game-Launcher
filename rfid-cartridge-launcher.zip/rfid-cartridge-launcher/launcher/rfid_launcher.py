#!/usr/bin/env python3
"""
rAge 2026 - RFID Cartridge Launcher (PC side)

Listens to the Raspberry Pi Pico + RC522 reader over USB and:
  - music tags: play a file, folder or playlist in VLC.
    Remove the cartridge to pause, put it back to resume.
  - game tags:  launch a Steam game, a URL (e.g. Epic) or an .exe
  - stop tags:  an "eject" card that stops the music

Tags are set up in tags.json next to this script. Any new tag you scan is
added there automatically as "unassigned", so you can scan all your
stickers first and fill in what each one does afterwards. tags.json is
re-read on every scan, so edits take effect without restarting.

It also serves two pages from the "frontend" folder:
  http://localhost:8765          the visitor screen (the cartridge shelf)
  http://localhost:8765/manage   a form for setting up cartridges, so you
                                 don't have to edit tags.json by hand

Requirements: Python 3.8+, VLC 3.x, and:  pip install pyserial
"""

import base64
import json
import mimetypes
import os
import queue
import shutil
import subprocess
import sys
import threading
import time
import urllib.request
from datetime import datetime
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import unquote, urlparse

try:
    import serial
    from serial.tools import list_ports
except ImportError as e:
    sys.exit(
        "Couldn't load pyserial: {}\n"
        "Python running this script: {}\n"
        "Install it for this Python with:\n"
        '  "{}" -m pip install pyserial'.format(e, sys.executable, sys.executable))

CONFIG_PATH = Path(__file__).with_name("tags.json")
FRONTEND_DIR = Path(__file__).with_name("frontend")
IMAGES_DIR = Path(__file__).with_name("images")
CONFIG_LOCK = threading.RLock()  # the launcher and the setup page both write tags.json
READER_USB_VIDS = {0x2E8A, 0x303A}  # Raspberry Pi (Pico), Espressif (ESP32)

DEFAULT_SETTINGS = {
    "serial_port": "auto",            # or a fixed port like "COM5" (recommended at the expo)
    "vlc_path": r"C:\Program Files\VideoLAN\VLC\vlc.exe",
    "vlc_hidden": True,               # True = audio only, no VLC window over the game
    "vlc_http_port": 8089,
    "vlc_http_password": "rage2026",
    "pause_on_remove": True,          # False = stop instead of pause
    "stop_after_paused_seconds": 60,  # paused this long = stop completely (0 = never)
    "stop_music_on_game": True,
    "game_relaunch_cooldown_seconds": 20,
    "screen_port": 8765,
    "screen_host": "127.0.0.1",       # "0.0.0.0" lets a tablet on the same network open the screen
    "screen_title": "Cartridge Bay",
    "screen_subtitle": "PiShop at rAge 2026",
    "screen_footer": "Built with a Raspberry Pi Pico and an RC522 RFID reader",
}


def log(msg):
    print(f"[{datetime.now():%H:%M:%S}] {msg}", flush=True)


# ---------------------------------------------------------------- config

def load_config(last_good=None):
    """Returns (config, loaded_ok). Keeps the last good config if the file has a typo."""
    try:
        with open(CONFIG_PATH, encoding="utf-8") as f:
            cfg = json.load(f)
    except FileNotFoundError:
        cfg = {"settings": dict(DEFAULT_SETTINGS), "tags": {}}
        save_config(cfg)
        log(f"Created a new {CONFIG_PATH.name}")
        return cfg, True
    except json.JSONDecodeError as e:
        log(f"{CONFIG_PATH.name} has an error on line {e.lineno}: {e.msg}. Using the last good version.")
        return (last_good or {"settings": dict(DEFAULT_SETTINGS), "tags": {}}), False

    settings = dict(DEFAULT_SETTINGS)
    settings.update(cfg.get("settings", {}))
    cfg["settings"] = settings
    cfg["tags"] = {uid.upper(): entry for uid, entry in cfg.get("tags", {}).items()}
    return cfg, True


def save_config(cfg):
    tmp = CONFIG_PATH.with_suffix(".tmp")
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(cfg, f, indent=2, ensure_ascii=False)
    tmp.replace(CONFIG_PATH)


class ConfigError(Exception):
    pass


def edit_config(change):
    """Reads tags.json as it is on disk, applies change(config), and saves it.
    Refuses to touch a file that has a typo, so nothing is lost."""
    with CONFIG_LOCK:
        try:
            raw = json.loads(CONFIG_PATH.read_text(encoding="utf-8"))
        except FileNotFoundError:
            raw = {"settings": {}, "tags": {}}
        except json.JSONDecodeError as e:
            raise ConfigError(f"tags.json has a mistake on line {e.lineno} ({e.msg}). "
                              "Fix it in Notepad, then try again.")
        raw.setdefault("tags", {})
        result = change(raw)
        save_config(raw)
        return result


# ---------------------------------------------------------------- helpers

def open_uri(uri):
    if os.name == "nt":
        os.startfile(uri)
    else:
        subprocess.Popen(["xdg-open", uri])


def find_vlc(settings):
    candidates = [
        settings.get("vlc_path"),
        r"C:\Program Files\VideoLAN\VLC\vlc.exe",
        r"C:\Program Files (x86)\VideoLAN\VLC\vlc.exe",
        shutil.which("vlc"),
    ]
    for c in candidates:
        if c and Path(c).exists():
            return c
    return None


def open_port(port, timeout):
    """Opens the port with DTR on and RTS off. MicroPython on the Pico only
    sends output while DTR is on, and RTS off avoids resetting ESP32 boards."""
    ser = serial.Serial()
    ser.port = port
    ser.baudrate = 115200
    ser.timeout = timeout
    ser.dtr = True
    ser.rts = False
    ser.open()
    return ser


def is_launcher_reader(port):
    """Asks a port whether it is the RFID reader, so other boards (light towers, stream deck) are skipped."""
    try:
        with open_port(port, 0.3) as ser:
            ser.reset_input_buffer()
            ser.write(b"PING\n")
            deadline = time.monotonic() + 1.5
            while time.monotonic() < deadline:
                line = ser.readline().decode("ascii", errors="ignore").strip()
                if line.startswith("READY:RFID"):
                    return True
    except (serial.SerialException, OSError):
        pass  # port busy (e.g. HyperHDR has the light towers open) or not ours
    return False


def find_port(settings):
    if str(settings.get("serial_port", "auto")).lower() != "auto":
        return settings["serial_port"]
    for p in list_ports.comports():
        if p.vid in READER_USB_VIDS and is_launcher_reader(p.device):
            return p.device
    return None


# ---------------------------------------------------------------- music

class MusicPlayer:
    """Runs VLC as a separate process and controls it through VLC's local web interface."""

    def __init__(self):
        self.proc = None
        self.tag = None
        self.paused_at = None
        self.port = None
        self.password = None

    def running(self):
        return self.proc is not None and self.proc.poll() is None

    def play(self, uid, entry, settings):
        self.stop()
        vlc = find_vlc(settings)
        if not vlc:
            log("VLC not found. Install VLC or set vlc_path in tags.json.")
            return "VLC isn't installed, or vlc_path in tags.json is wrong"
        path = entry.get("path")
        if not path or not Path(path).exists():
            log(f"Music path not found: {path}")
            return "The music folder for this cartridge can't be found"

        self.port = int(settings["vlc_http_port"])
        self.password = str(settings["vlc_http_password"])
        args = [
            vlc, "--no-one-instance", "--no-playlist-enqueue",
            "--extraintf", "http", "--http-host", "127.0.0.1",
            "--http-port", str(self.port), "--http-password", self.password,
        ]
        flags = 0
        if settings.get("vlc_hidden", True):
            args += ["--intf", "dummy"]
            if os.name == "nt":
                args.append("--dummy-quiet")
                flags = subprocess.CREATE_NO_WINDOW
        if entry.get("shuffle"):
            args.append("--random")
        if entry.get("loop", True):
            args.append("--loop")
        args.append(str(path))

        self.proc = subprocess.Popen(args, creationflags=flags)
        self.tag = uid
        self.paused_at = None
        log(f"PLAY   {entry.get('name', uid)}")
        return None

    def _command(self, command):
        if not self.running():
            return False
        req = urllib.request.Request(
            f"http://127.0.0.1:{self.port}/requests/status.xml?command={command}")
        token = base64.b64encode(f":{self.password}".encode()).decode()
        req.add_header("Authorization", f"Basic {token}")
        try:
            urllib.request.urlopen(req, timeout=2).read()
            return True
        except Exception as e:
            log(f"Couldn't reach VLC ({e})")
            return False

    def pause(self):
        if self._command("pl_forcepause"):
            self.paused_at = time.monotonic()
            log("PAUSE  cartridge removed")

    def resume(self):
        if self._command("pl_forceresume"):
            self.paused_at = None
            log("RESUME cartridge back")
            return True
        return False

    def stop(self):
        if self.running():
            self.proc.terminate()
            try:
                self.proc.wait(timeout=3)
            except subprocess.TimeoutExpired:
                self.proc.kill()
            log("STOP   music")
        self.proc = None
        self.tag = None
        self.paused_at = None

    def tick(self, settings):
        if self.proc is not None and not self.running():  # VLC closed or crashed
            self.proc = None
            self.tag = None
            self.paused_at = None
        limit = settings.get("stop_after_paused_seconds", 60)
        if self.paused_at is not None and limit and time.monotonic() - self.paused_at > limit:
            log(f"Paused for over {limit}s")
            self.stop()


# ---------------------------------------------------------------- visitor screen state

class ScreenState:
    """What the visitor screen should show. Every change is pushed to open screens."""

    def __init__(self):
        self._lock = threading.Lock()
        self._clients = set()
        self._state = {"status": "idle", "uid": None, "active": None, "name": "",
                       "kind": "", "subtitle": "", "message": "", "reader": False}

    def get(self, key):
        with self._lock:
            return self._state.get(key)

    def snapshot(self):
        with self._lock:
            snap = dict(self._state)
        try:
            snap["tags_version"] = CONFIG_PATH.stat().st_mtime_ns
        except OSError:
            snap["tags_version"] = 0
        return snap

    def update(self, **changes):
        with self._lock:
            self._state.update(changes)
        data = json.dumps(self.snapshot())
        with self._lock:
            clients = list(self._clients)
        for q in clients:
            try:
                q.put_nowait(data)
            except queue.Full:
                pass

    def subscribe(self):
        q = queue.Queue(maxsize=50)
        with self._lock:
            self._clients.add(q)
        return q

    def unsubscribe(self, q):
        with self._lock:
            self._clients.discard(q)


# ---------------------------------------------------------------- tag handling

class Launcher:
    def __init__(self, screen):
        self.cfg, _ = load_config()
        self.player = MusicPlayer()
        self.last_launch = {}
        self.screen = screen
        self.scans = 0
        self.lock = threading.RLock()  # the serial loop and the setup page can both act

    @property
    def settings(self):
        return self.cfg["settings"]

    def show(self, status, uid=None, entry=None, lifted=False, message=""):
        entry = entry or {}
        self.screen.update(status=status, uid=uid, active=uid if lifted else None,
                           name=entry.get("name", ""), kind=entry.get("type", ""),
                           subtitle=entry.get("subtitle", ""), message=message)

    def screen_info(self):
        cfg, _ = load_config(self.cfg)
        s = cfg["settings"]
        tags = [{"uid": uid, "name": e.get("name") or uid, "kind": e["type"],
                 "subtitle": e.get("subtitle", ""), "color": e.get("color", ""),
                 "image": image_url(uid, e)}
                for uid, e in cfg["tags"].items() if e.get("type") in ("game", "music")]
        return {"tags": tags, "title": s["screen_title"],
                "subtitle": s["screen_subtitle"], "footer": s["screen_footer"]}

    def handle(self, line):
        with self.lock:
            self._handle(line)

    def _handle(self, line):
        if line.startswith("TAG:"):
            self.on_tag(line[4:].strip().upper())
        elif line.startswith("REMOVED:"):
            self.on_removed(line[8:].strip().upper())
        elif line.startswith("READY"):
            log("Reader ready")
        elif line.startswith("ERROR:"):
            log(f"Reader problem: {line[6:]} (check the RC522 wiring)")

    def on_tag(self, uid):
        self.cfg, loaded_ok = load_config(self.cfg)
        entry = self.cfg["tags"].get(uid)

        self.scans += 1
        self.screen.update(last_scan=uid, scan_seq=self.scans)

        if entry is None:
            log(f"NEW    tag {uid}: open http://localhost:{self.settings['screen_port']}/manage to set it up")
            try:
                edit_config(lambda raw: raw["tags"].setdefault(uid, {"name": "New tag", "type": "unassigned"}))
                self.cfg, _ = load_config(self.cfg)
            except ConfigError as e:
                log(str(e))
            self.show("new", uid)
            return

        kind = entry.get("type")
        if kind == "music":
            if self.player.tag == uid and self.player.running() and self.player.resume():
                self.show("playing", uid, entry, lifted=True)
                return
            problem = self.player.play(uid, entry, self.settings)
            if problem:
                self.show("error", uid, entry, message=problem)
            else:
                self.show("playing", uid, entry, lifted=True)
        elif kind == "game":
            result = self.launch_game(uid, entry)
            if result in ("launched", "cooldown"):
                self.show("launching" if result == "launched" else "cooldown", uid, entry, lifted=True)
            else:
                self.show("error", uid, entry, message=result)
        elif kind == "stop":
            self.player.stop()
            self.show("stopped", uid, entry)
        elif kind == "unassigned":
            log(f"Tag {uid} is still unassigned in {CONFIG_PATH.name}")
            self.show("unassigned", uid, entry)
        else:
            log(f"Tag {uid} has an unknown type: {kind}")
            self.show("error", uid, entry, message=f"Unknown type '{kind}' in tags.json")

    def on_removed(self, uid):
        entry = self.cfg["tags"].get(uid, {})
        if uid == self.player.tag and self.player.running():
            if entry.get("pause_on_remove", self.settings["pause_on_remove"]):
                self.player.pause()
                if self.player.paused_at is not None:
                    self.show("paused", uid, entry)
                    return
            self.player.stop()
        if self.screen.get("uid") == uid:
            self.show("idle")

    def launch_game(self, uid, entry):
        """Returns "launched", "cooldown", or a description of what went wrong."""
        name = entry.get("name", uid)
        now = time.monotonic()
        cooldown = self.settings["game_relaunch_cooldown_seconds"]
        if now - self.last_launch.get(uid, float("-inf")) < cooldown:
            log(f"'{name}' was just launched, ignoring the repeat scan")
            return "cooldown"
        try:
            if entry.get("steam_id"):
                target = f"steam://rungameid/{entry['steam_id']}"
                launch = lambda: open_uri(target)
            elif entry.get("url"):
                launch = lambda: open_uri(entry["url"])
            elif entry.get("exe"):
                exe = Path(entry["exe"])
                if not exe.is_file():
                    log(f"'{name}': exe not found at {exe}")
                    return "The game's .exe can't be found at the path in tags.json"
                launch = lambda: subprocess.Popen([str(exe), *entry.get("args", [])],
                                                  cwd=str(exe.parent))
            else:
                log(f"'{name}' has no steam_id, url or exe set")
                return "This game has no steam_id, url or exe in tags.json"
            if self.settings["stop_music_on_game"]:
                self.player.stop()
            launch()
            self.last_launch[uid] = now
            log(f"GAME   {name}")
            return "launched"
        except Exception as e:
            log(f"Couldn't launch '{name}': {e}")
            return f"Windows couldn't start it: {e}"

    def tick(self):
        with self.lock:
            self._tick()

    def _tick(self):
        self.player.tick(self.settings)
        if self.screen.get("status") in ("playing", "paused") and not self.player.running():
            self.show("idle")  # music ended, was stopped after a long pause, or VLC was closed


# ---------------------------------------------------------------- setup page helpers

ENTRY_FIELDS = ("name", "type", "steam_id", "exe", "url", "path", "shuffle", "loop",
                "pause_on_remove", "subtitle", "color", "image")
BROWSE_LOCK = threading.Lock()


def image_url(uid, entry):
    image = entry.get("image")
    if not image:
        return None
    try:
        version = Path(image).stat().st_mtime_ns
    except OSError:
        version = 0
    return f"/api/image/{uid}?v={version}"


def clean_entry(data):
    """Checks a cartridge sent from the setup page. Returns (entry, problem)."""
    name = str(data.get("name", "")).strip()
    kind = data.get("type")
    if not name:
        return None, "Give the cartridge a name."
    if kind not in ("game", "music", "stop"):
        return None, "Choose whether it's a game, music or a stop card."
    entry = {"name": name, "type": kind}

    if kind == "game":
        steam_id = str(data.get("steam_id", "")).strip()
        exe = str(data.get("exe", "")).strip().strip('"')
        url = str(data.get("url", "")).strip()
        if steam_id:
            if not steam_id.isdigit():
                return None, "The Steam app ID should be a number, like 1030300."
            entry["steam_id"] = steam_id
        elif exe:
            if not Path(exe).is_file():
                return None, "That program can't be found. Use Browse to pick the game's .exe."
            entry["exe"] = exe
        elif url:
            entry["url"] = url
        else:
            return None, "Add a Steam link, a program or a launch link for the game."

    if kind == "music":
        path = str(data.get("path", "")).strip().strip('"')
        if not path:
            return None, "Choose the music folder or file."
        if not Path(path).exists():
            return None, "That music folder or file can't be found. Use Browse to pick it."
        entry["path"] = path
        entry["shuffle"] = bool(data.get("shuffle"))
        entry["loop"] = bool(data.get("loop", True))
        entry["pause_on_remove"] = bool(data.get("pause_on_remove", True))

    subtitle = str(data.get("subtitle", "")).strip()
    if subtitle:
        entry["subtitle"] = subtitle
    color = str(data.get("color", "")).strip()
    if color:
        entry["color"] = color
    image = str(data.get("image", "")).strip().strip('"')
    if image:
        if not Path(image).is_file():
            return None, "The cover image can't be found. Choose it again."
        entry["image"] = image
    return entry, None


def browse_for(what):
    """Opens a Windows file dialog on this PC. Returns (path, problem)."""
    try:
        import tkinter as tk
        from tkinter import filedialog
    except ImportError:
        return None, "Browse needs tkinter, which this Python doesn't have. Paste the path instead."
    with BROWSE_LOCK:
        root = tk.Tk()
        root.withdraw()
        root.attributes("-topmost", True)
        try:
            if what == "folder":
                path = filedialog.askdirectory(parent=root, title="Choose the music folder")
            elif what == "exe":
                path = filedialog.askopenfilename(parent=root, title="Choose the game's program",
                                                  filetypes=[("Programs", "*.exe"), ("All files", "*.*")])
            else:
                path = filedialog.askopenfilename(parent=root, title="Choose a music file or playlist",
                                                  filetypes=[("Music", "*.mp3 *.flac *.ogg *.wav *.m4a *.m3u *.m3u8 *.xspf"),
                                                             ("All files", "*.*")])
        finally:
            root.destroy()
    return (str(Path(path)) if path else None), None


def manage_listing(launcher):
    try:
        raw = json.loads(CONFIG_PATH.read_text(encoding="utf-8"))
        problem = None
    except FileNotFoundError:
        raw, problem = {"tags": {}}, None
    except json.JSONDecodeError as e:
        cfg, _ = load_config(launcher.cfg)
        raw = {"tags": cfg["tags"]}
        problem = f"tags.json has a mistake on line {e.lineno} ({e.msg}). Saving is off until it's fixed."
    tags = []
    for uid, e in raw.get("tags", {}).items():
        item = {k: e[k] for k in ENTRY_FIELDS if k in e}
        item["uid"] = uid
        item["preview"] = image_url(uid, e)
        tags.append(item)
    defaults = dict(DEFAULT_SETTINGS)
    defaults.update(raw.get("settings", {}))
    return {"tags": tags, "problem": problem, "pause_on_remove": defaults["pause_on_remove"]}


# ---------------------------------------------------------------- visitor screen server

def make_handler(screen, launcher):
    class Handler(BaseHTTPRequestHandler):
        def log_message(self, *args):
            pass  # keep the launcher window readable

        def do_GET(self):
            path = unquote(urlparse(self.path).path)
            if path in ("/", "/index.html"):
                return self.send_file(FRONTEND_DIR / "index.html")
            if path.startswith("/fonts/"):
                return self.send_file(FRONTEND_DIR / "fonts" / Path(path).name)
            if path == "/api/tags":
                return self.send_json(launcher.screen_info())
            if path == "/api/state":
                return self.send_json(screen.snapshot())
            if path.startswith("/api/image/"):
                uid = path.rsplit("/", 1)[-1].upper()
                cfg, _ = load_config(launcher.cfg)
                image = cfg["tags"].get(uid, {}).get("image")
                return self.send_file(Path(image)) if image else self.send_error(404)
            if path == "/api/events":
                return self.stream_events()
            if path == "/manage":
                return self.send_file(FRONTEND_DIR / "manage.html")
            if path == "/api/manage":
                return self.send_json(manage_listing(launcher))
            self.send_error(404)

        def do_POST(self):
            path = unquote(urlparse(self.path).path)
            if self.client_address[0] not in ("127.0.0.1", "::1"):
                return self.send_json({"error": "Cartridges can only be set up on the PC running the launcher."}, 403)
            length = int(self.headers.get("Content-Length") or 0)
            if length > 20 * 1024 * 1024:
                return self.send_json({"error": "That file is too big. Use an image under 20 MB."}, 413)
            body = self.rfile.read(length)

            if path == "/api/browse":
                what = json.loads(body or b"{}").get("what", "file")
                found, problem = browse_for(what)
                return self.send_json({"path": found, "error": problem})

            if path == "/api/upload-image":
                uid = (urlparse(self.path).query.partition("uid=")[2] or "cover").upper()
                uid = "".join(c for c in uid if c.isalnum()) or "cover"
                ext = Path(self.headers.get("X-Filename", "cover.jpg")).suffix.lower()
                if ext not in (".jpg", ".jpeg", ".png", ".webp", ".gif"):
                    return self.send_json({"error": "Use a JPG, PNG, WebP or GIF image."}, 400)
                IMAGES_DIR.mkdir(exist_ok=True)
                for old in IMAGES_DIR.glob(uid + ".*"):
                    old.unlink(missing_ok=True)
                target = IMAGES_DIR / (uid + ext)
                target.write_bytes(body)
                return self.send_json({"path": str(target)})

            if path.startswith("/api/cartridge/"):
                uid = path.split("/")[3].upper()
                try:
                    if path.endswith("/delete"):
                        edit_config(lambda raw: raw["tags"].pop(uid, None))
                        log(f"DELETE {uid} (setup page)")
                        return self.send_json({"ok": True})
                    entry, problem = clean_entry(json.loads(body or b"{}"))
                    if problem:
                        return self.send_json({"error": problem}, 400)

                    def store(raw):
                        old = raw["tags"].get(uid, {})
                        kept = {k: v for k, v in old.items() if k not in ENTRY_FIELDS}
                        raw["tags"][uid] = {**entry, **kept}
                    edit_config(store)
                    log(f"SAVED  {uid} as '{entry['name']}' (setup page)")
                    with launcher.lock:
                        launcher.cfg, _ = load_config(launcher.cfg)
                        if launcher.screen.get("uid") == uid and launcher.screen.get("status") in ("new", "unassigned"):
                            launcher.show("idle")
                    screen.update()  # tells open pages that tags.json changed
                    return self.send_json({"ok": True})
                except ConfigError as e:
                    return self.send_json({"error": str(e)}, 409)
            self.send_error(404)

        def send_file(self, file):
            if not file.is_file():
                return self.send_error(404)
            body = file.read_bytes()
            self.send_response(200)
            self.send_header("Content-Type", mimetypes.guess_type(file.name)[0] or "application/octet-stream")
            self.send_header("Content-Length", str(len(body)))
            self.send_header("Cache-Control", "no-cache")
            self.end_headers()
            self.wfile.write(body)

        def send_json(self, data, code=200):
            body = json.dumps(data).encode()
            self.send_response(code)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(body)))
            self.send_header("Cache-Control", "no-store")
            self.end_headers()
            self.wfile.write(body)

        def stream_events(self):
            self.send_response(200)
            self.send_header("Content-Type", "text/event-stream")
            self.send_header("Cache-Control", "no-cache")
            self.end_headers()
            q = screen.subscribe()
            try:
                self.push(json.dumps(screen.snapshot()))
                while True:
                    try:
                        data = q.get(timeout=15)
                    except queue.Empty:
                        data = json.dumps(screen.snapshot())  # heartbeat, also picks up tags.json edits
                    self.push(data)
            except OSError:
                pass  # the screen was closed or refreshed
            finally:
                screen.unsubscribe(q)

        def push(self, data):
            self.wfile.write(f"data: {data}\n\n".encode())
            self.wfile.flush()

    return Handler


def start_screen_server(screen, launcher):
    s = launcher.settings
    host, port = s["screen_host"], int(s["screen_port"])
    if not (FRONTEND_DIR / "index.html").is_file():
        log("No frontend folder next to the script, so the visitor screen is off.")
        return
    try:
        server = ThreadingHTTPServer((host, port), make_handler(screen, launcher))
    except OSError as e:
        log(f"Couldn't start the visitor screen on port {port} ({e}). Change screen_port in tags.json.")
        return
    server.daemon_threads = True
    threading.Thread(target=server.serve_forever, daemon=True).start()
    log(f"Visitor screen: open http://localhost:{port} in a browser")
    log(f"Cartridge setup: open http://localhost:{port}/manage")
    if host == "0.0.0.0":
        log(f"Other devices on this network can use http://<this PC's IP address>:{port}")


# ---------------------------------------------------------------- main loop

def main():
    screen = ScreenState()
    launcher = Launcher(screen)
    log("RFID launcher started. Press Ctrl+C to quit.")
    start_screen_server(screen, launcher)
    waiting_logged = False
    try:
        while True:
            port = find_port(launcher.settings)
            if not port:
                if not waiting_logged:
                    log("Waiting for the RFID reader to be plugged in...")
                    waiting_logged = True
                    screen.update(reader=False)
                launcher.tick()
                time.sleep(3)
                continue
            waiting_logged = False
            try:
                with open_port(port, 0.2) as ser:
                    log(f"Connected to reader on {port}")
                    screen.update(reader=True)
                    ser.reset_input_buffer()
                    ser.write(b"PING\n")
                    while True:
                        raw = ser.readline()
                        launcher.tick()
                        if raw:
                            line = raw.decode("ascii", errors="ignore").strip()
                            if line:
                                launcher.handle(line)
            except (serial.SerialException, OSError) as e:
                log(f"Lost the reader ({e}). Reconnecting...")
                screen.update(reader=False)
                time.sleep(2)
    except KeyboardInterrupt:
        log("Shutting down")
        launcher.player.stop()


if __name__ == "__main__":
    main()
