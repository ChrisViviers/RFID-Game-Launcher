"""Double-click this file to run the cartridge launcher in the background.

There's no Command Prompt window: look for the cartridge icon in the system
tray (bottom-right of the taskbar, possibly under the ^ arrow). Right-click
it for the visitor screen, cartridge setup, start-with-Windows and Quit.
Everything the launcher does is written to rfid_launcher.log.
"""
import sys
import traceback
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))


def message(text, title="Cartridge launcher"):
    """Shows a Windows message box, since there's no console to print to."""
    try:
        import ctypes
        ctypes.windll.user32.MessageBoxW(None, text, title, 0x10)
    except Exception:
        pass


try:
    import rfid_launcher
    rfid_launcher.main(tray=True)
except SystemExit as e:
    if e.code not in (None, 0):
        message(str(e.code))
except Exception:
    details = traceback.format_exc()
    try:
        rfid_launcher.log(details)
    except Exception:
        pass
    message("The cartridge launcher stopped because of an error:\n\n" + details[-1500:])
