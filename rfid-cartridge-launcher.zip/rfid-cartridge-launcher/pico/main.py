# rAge 2026 - RFID Cartridge Launcher (reader side)
# Board:  Raspberry Pi Pico / Pico W / Pico 2 running MicroPython
# Reader: RC522 (13.56 MHz) with NTAG213 stickers
#
# Save this file on the Pico as main.py, next to mfrc522.py.
# It sends one line per event over USB to rfid_launcher.py on the PC:
#   TAG:<UID>            a tag was placed on the reader
#   REMOVED:<UID>        that tag was taken away
#   READY:RFID-LAUNCHER  on start-up and in reply to "PING"
#   ERROR:<reason>       the RC522 is not responding (check wiring)
#
# Onboard LED: short blink every ~2 s = waiting, solid = tag present,
#              fast blinking = reader problem

import sys
import select
import time
from machine import Pin
from mfrc522 import MFRC522

# ---- Pins (SPI0)
PIN_MISO = 16  # physical pin 21
PIN_CS   = 17  # physical pin 22  (RC522 "SDA")
PIN_SCK  = 18  # physical pin 24
PIN_MOSI = 19  # physical pin 25
PIN_RST  = 20  # physical pin 26

# ---- Receiver gain (set from the results of rfid_test.py)
# 0x10=23dB, 0x40=33dB, 0x50=38dB, 0x60=43dB, 0x70=48dB
RX_GAIN = 0x10

# ---- Timing
POLL_MS = 120               # how often to look for a tag
MISSES_BEFORE_REMOVED = 4   # ~0.5 s with no tag = removed
HEALTH_CHECK_MS = 5000      # re-check the RC522 this often

led = Pin("LED", Pin.OUT)
reader = MFRC522(sck=PIN_SCK, mosi=PIN_MOSI, miso=PIN_MISO, cs=PIN_CS, rst=PIN_RST, gain=RX_GAIN)

stdin_poll = select.poll()
stdin_poll.register(sys.stdin, select.POLLIN)
cmd_buf = ""


def send(line):
    print(line)


def check_commands():
    global cmd_buf
    while stdin_poll.poll(0):
        c = sys.stdin.read(1)
        if c in ("\n", "\r"):
            if cmd_buf.strip() == "PING":
                send("READY:RFID-LAUNCHER")
            cmd_buf = ""
        elif len(cmd_buf) < 32:
            cmd_buf += c


def read_tag():
    """Returns the ID of the tag on the reader as hex text, or None."""
    stat, _ = reader.request(reader.REQALL)  # also wakes the tag we halted last poll
    if stat != reader.OK:
        return None
    uid = reader.read_uid()
    if uid is None:
        reader.reset_field()  # a half-finished read can leave the tag stuck
        return None
    reader.halt()
    return "".join("{:02X}".format(b) for b in uid)


def main():
    current = None
    misses = 0
    tick = 0
    reader_ok = reader.is_ok()
    last_health = time.ticks_ms()

    send("READY:RFID-LAUNCHER")
    if not reader_ok:
        send("ERROR:READER_NOT_RESPONDING")

    while True:
        try:
            check_commands()

            # The RC522 can lock up after a static shock or a loose wire.
            # Re-initialise it instead of needing a power cycle.
            if time.ticks_diff(time.ticks_ms(), last_health) > HEALTH_CHECK_MS:
                last_health = time.ticks_ms()
                if not reader.is_ok():
                    reader_ok = False
                    send("ERROR:READER_NOT_RESPONDING")
                    reader.init()
                elif not reader_ok:
                    reader_ok = True
                    reader.init()

            uid = read_tag() if reader_ok else None
            if uid:
                misses = 0
                if uid != current:
                    if current:
                        send("REMOVED:" + current)
                    current = uid
                    send("TAG:" + current)
            elif current:
                misses += 1
                if misses >= MISSES_BEFORE_REMOVED:
                    send("REMOVED:" + current)
                    current = None
                    misses = 0

            tick += 1
            if not reader_ok:
                led.value(tick % 2)
            elif current:
                led.on()
            else:
                led.value(1 if tick % 16 == 0 else 0)

        except Exception as e:  # keep running at the expo whatever happens
            send("ERROR:" + str(e))
            time.sleep_ms(500)
            try:
                reader.init()
            except Exception:
                pass

        time.sleep_ms(POLL_MS)


main()
