# Minimal MicroPython driver for the RC522 (MFRC522) RFID reader.
# Reads the ID of any ISO 14443A tag, including the 7-byte IDs of
# NTAG213 stickers. Save this file on the Pico as mfrc522.py.

from machine import Pin, SPI
import time


class MFRC522:
    OK = 0
    NOTAGERR = 1
    ERR = 2

    REQIDL = 0x26  # wake tags that are idle
    REQALL = 0x52  # wake tags that are idle or halted

    def __init__(self, sck, mosi, miso, cs, rst, spi_id=0, baudrate=1_000_000, gain=0x70):
        self.gain = gain
        self.spi = SPI(spi_id, baudrate=baudrate, polarity=0, phase=0,
                       sck=Pin(sck), mosi=Pin(mosi), miso=Pin(miso))
        self.cs = Pin(cs, Pin.OUT, value=1)
        self.rst = Pin(rst, Pin.OUT, value=0)
        time.sleep_ms(10)
        self.rst.value(1)
        time.sleep_ms(50)
        self.init()

    # ---- low-level register access

    def _wreg(self, reg, val):
        self.cs.value(0)
        self.spi.write(bytes([(reg << 1) & 0x7E, val & 0xFF]))
        self.cs.value(1)

    def _rreg(self, reg):
        self.cs.value(0)
        self.spi.write(bytes([((reg << 1) & 0x7E) | 0x80]))
        val = self.spi.read(1)
        self.cs.value(1)
        return val[0]

    def _sflags(self, reg, mask):
        self._wreg(reg, self._rreg(reg) | mask)

    def _cflags(self, reg, mask):
        self._wreg(reg, self._rreg(reg) & (~mask & 0xFF))

    # ---- setup

    def init(self):
        self._wreg(0x01, 0x0F)  # soft reset
        time.sleep_ms(50)
        self._wreg(0x2A, 0x8D)  # timer: auto start, prescaler high bits
        self._wreg(0x2B, 0x3E)  # prescaler low bits (~1 ms per tick)
        self._wreg(0x2D, 30)    # timeout ~30 ms
        self._wreg(0x2C, 0)
        self._wreg(0x15, 0x40)  # 100% ASK modulation
        self._wreg(0x11, 0x3D)  # CRC preset 0x6363
        self.set_gain(self.gain)
        self.antenna_on()

    def set_gain(self, gain):
        """Receiver gain: 0x10=23dB, 0x40=33dB, 0x50=38dB, 0x60=43dB, 0x70=48dB."""
        self.gain = gain & 0x70
        self._wreg(0x26, (self._rreg(0x26) & 0x8F) | self.gain)

    def antenna_on(self):
        if not (self._rreg(0x14) & 0x03):
            self._sflags(0x14, 0x03)

    def antenna_off(self):
        self._cflags(0x14, 0x03)

    def reset_field(self):
        """Switch the field off and on so every tag restarts in its idle state."""
        self.antenna_off()
        time.sleep_ms(3)
        self.antenna_on()
        time.sleep_ms(5)

    def is_ok(self):
        v = self._rreg(0x37)  # VersionReg
        return v not in (0x00, 0xFF)

    # ---- talking to tags

    def _tocard(self, cmd, send):
        recv = []
        bits = 0
        irq_en = 0x77 if cmd == 0x0C else 0x12
        wait_irq = 0x30 if cmd == 0x0C else 0x10

        self._wreg(0x02, irq_en | 0x80)
        self._wreg(0x04, 0x7F)    # clear all interrupt flags
        self._sflags(0x0A, 0x80)  # flush FIFO
        self._wreg(0x01, 0x00)    # idle
        for c in send:
            self._wreg(0x09, c)
        self._wreg(0x01, cmd)
        if cmd == 0x0C:
            self._sflags(0x0D, 0x80)  # start sending

        tries = 2000
        while True:
            n = self._rreg(0x04)
            tries -= 1
            if (n & 0x01) or (n & wait_irq) or tries == 0:
                break
        self._cflags(0x0D, 0x80)

        if tries == 0 or (self._rreg(0x06) & 0x1B):
            return self.ERR, recv, bits
        if n & irq_en & 0x01:
            return self.NOTAGERR, recv, bits

        if cmd == 0x0C:
            count = self._rreg(0x0A)
            last_bits = self._rreg(0x0C) & 0x07
            bits = (count - 1) * 8 + last_bits if last_bits else count * 8
            count = max(1, min(count, 16))
            for _ in range(count):
                recv.append(self._rreg(0x09))
        return self.OK, recv, bits

    def _crc(self, data):
        self._wreg(0x01, 0x00)    # idle
        self._wreg(0x05, 0x04)    # clear the CRC-done flag
        self._sflags(0x0A, 0x80)  # flush FIFO
        for c in data:
            self._wreg(0x09, c)
        self._wreg(0x01, 0x03)  # calculate CRC
        tries = 255
        while True:
            n = self._rreg(0x05)
            tries -= 1
            if tries == 0 or (n & 0x04):
                break
        return [self._rreg(0x22), self._rreg(0x21)]

    def request(self, mode=REQIDL):
        self._wreg(0x0D, 0x07)  # 7-bit frame
        stat, recv, bits = self._tocard(0x0C, [mode])
        if stat == self.OK and bits != 0x10:
            stat = self.ERR  # something answered, but not a proper reply
        return stat, bits

    def _anticoll(self, cascade):
        self._wreg(0x0D, 0x00)
        self._cflags(0x0E, 0x80)  # keep received bits after a collision
        stat, recv, bits = self._tocard(0x0C, [cascade, 0x20])
        if stat == self.OK:
            if len(recv) == 5 and (recv[0] ^ recv[1] ^ recv[2] ^ recv[3]) == recv[4]:
                return self.OK, recv
            return self.ERR, recv
        return stat, recv

    def _select(self, cascade, part):
        buf = [cascade, 0x70] + part[:5]
        buf += self._crc(buf)
        stat, recv, bits = self._tocard(0x0C, buf)
        if stat == self.OK and bits == 0x18 and recv:
            return self.OK, recv[0]
        return self.ERR, 0

    def read_uid(self):
        """Returns the tag's full ID as a list of bytes, or None if the read failed."""
        uid = []
        for cascade in (0x93, 0x95, 0x97):
            stat, part = self._anticoll(cascade)
            if stat != self.OK:
                return None
            stat, sak = self._select(cascade, part)
            if stat != self.OK:
                return None
            uid += part[1:4] if part[0] == 0x88 else part[0:4]
            if not (sak & 0x04):  # no more ID bytes to come
                return uid
        return uid

    def halt(self):
        buf = [0x50, 0x00]
        buf += self._crc(buf)
        self._tocard(0x0C, buf)
