# RC522 gain test for the Pico (version 3).
# In Thonny: click Stop, open this file and press Run (F5).
# Put ONE sticker flat on the reader before starting and keep it still
# until the summary appears (about 30 seconds). Keep all other tags,
# cards and the rest of the sticker pack well away from the reader.
from mfrc522 import MFRC522
import time

r = MFRC522(sck=18, mosi=19, miso=16, cs=17, rst=20)
print("RC522 version: 0x{:02X}".format(r._rreg(0x37)))

GAINS = ((0x10, "23 dB"), (0x40, "33 dB"), (0x50, "38 dB"), (0x60, "43 dB"), (0x70, "48 dB"))
TRIES = 20
results = []

for gain, label in GAINS:
    r.set_gain(gain)
    r.reset_field()
    good = garbled = silent = 0
    last_id = None
    for _ in range(TRIES):
        stat, bits = r.request(r.REQALL)
        if stat == r.OK:
            uid = r.read_uid()
            if uid:
                good += 1
                last_id = "".join("{:02X}".format(b) for b in uid)
                r.halt()
            else:
                garbled += 1
                r.reset_field()
        elif stat == r.NOTAGERR:
            silent += 1
        else:
            garbled += 1
            r.reset_field()
        time.sleep_ms(150)
    results.append((label, gain, good))
    print("Gain {} (0x{:02X}): read OK {}/{}, garbled {}, no answer {}{}".format(
        label, gain, good, TRIES, garbled, silent, ", ID " + last_id if last_id else ""))

best = max(results, key=lambda x: x[2])
if best[2] == 0:
    print("No gain setting could read the tag.")
else:
    print("Best: {} -> set RX_GAIN = 0x{:02X} in main.py".format(best[0], best[1]))
